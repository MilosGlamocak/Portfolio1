import { Container } from "@mui/material";
import AnimatedPage from "./AnimatedPage";
import './Projects.css'
import { useState, useRef, useContext } from "react";
import { useScroll, useTransform, motion } from "framer-motion";
import { ThemeContext } from "./Root";

function Projects() {

    const {theme, setTheme} = useContext(ThemeContext);
    const container = useRef(null)

    let [scrollTop, setScrollTop] = useState(0);
    let scrollSpeed = 100;
    const {scrollYProgress} = useScroll({
        target: container,
        offset: ['start end', 'end start']
    })



    return (
        <AnimatedPage>
            <Container ref={container.current} className="projectsCont" sx={{
                display: 'flex',
                overflowY: 'auto',
                padding: '700px'
            }}>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
                <a href="https://codepen.io/Milos-Glamocak" className={`projectsLink ${theme === 'dark' ? 'darkText' : 'lightText'}`} target="blank">CodePen</a>
            </Container>
        </AnimatedPage>
    )
}

export default Projects

/** */