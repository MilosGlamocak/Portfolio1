import React, { useState } from "react";
import InputComponent from "./CustomInput";

function TodoList() {
    let [task, setTask] = useState('');
    let [currentTasks, setCurrentTasks] = useState([]);

    function handleAddTask() {
        if (task.length < 1) {
            alert('Invalid input!')
        } else {
            setCurrentTasks([task, ...currentTasks]);
            setTask('');
        }
    }

    function handleDeleteTask(index) {
        let newTasks = [...currentTasks];
        newTasks.splice(index, 1);
        setCurrentTasks(newTasks);
    }

    return (
        <div style={{width: '100%', minHeight: '100vh', backgroundColor: 'gray', display: 'flex', alignItems: 'center', flexDirection: 'column'}}>
            <InputComponent inputType="text" inputId="todoItem" inputValue={task} required onChangeCustom={(e) => setTask(e.target.value)}/>
            <button onClick={handleAddTask}>Add Task</button>
            <div style={{width: '600px', minHeight: '70vh',backgroundColor: 'white', marginTop: '20px', gap: '5px', display: 'flex', flexDirection: 'column'}}>
                
                    {currentTasks.length < 1 ? <p style={{textAlign: 'center'}}>Add some tasks!</p> :  currentTasks.map((element, index) => {
                        return (
                            // ovde bi trebala ici custom div komponenta, ali nisam je stigao napraviti
                        <div style={{display: 'flex', flexDirection: 'row', justifyContent: 'space-between', padding: '10px', backgroundColor: 'beige', width: '600px', height: '70px', }} key={index}>
                            <p style={{}}>{element}</p>
                            <button onClick={() => handleDeleteTask(index)}>Remove</button>
                        </div>
                        )
                        
                    })}
                
            </div>

        </div>
    )

}

export default TodoList